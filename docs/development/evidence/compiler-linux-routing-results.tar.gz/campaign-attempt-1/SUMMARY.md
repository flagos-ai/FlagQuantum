# COMPILER-CANDIDATE execution evidence

Scope: unqualified protocol execution. Publication eligible: false.

No ranking is inferred. A qualification pass is one process block, not complete-case acceptance.

| SDK | Instance | Qualification outcome | Full-case outcome | Records |
| --- | --- | --- | --- | --- |
| fq-integrated-ordinary | ROUTE-LINE-06 | accepted | accepted | 30 |
| fq-integrated-ordinary | ROUTE-GRID-08 | accepted | accepted | 30 |
| fq-integrated-ordinary | ROUTE-LINE-12 | accepted | accepted | 30 |
| fq-integrated-artifact | ROUTE-LINE-06 | accepted | accepted | 30 |
| fq-integrated-artifact | ROUTE-GRID-08 | accepted | accepted | 30 |
| fq-integrated-artifact | ROUTE-LINE-12 | accepted | accepted | 30 |
| qiskit-release-restored | ROUTE-LINE-06 | accepted | accepted | 30 |
| qiskit-release-restored | ROUTE-GRID-08 | accepted | accepted | 30 |
| qiskit-release-restored | ROUTE-LINE-12 | accepted | accepted | 30 |
| cirq-release-restored | ROUTE-LINE-06 | accepted | accepted | 30 |
| cirq-release-restored | ROUTE-GRID-08 | accepted | accepted | 30 |
| cirq-release-restored | ROUTE-LINE-12 | accepted | accepted | 30 |
