"""Run the publicly frozen unchanged routing protocol after host admission."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/data/sdkbench-compiler-qualification-20261123')
HARNESS = ROOT / 'harness-source/sdkbench-org-sdkbench-9cb8f18'
PARENT = Path('/sys/fs/cgroup/sdkbench-compiler-qualification-20261123')
PYTHON = ROOT / 'qualification-env/bin/python'
STUDY = ROOT / 'campaign-attempt-1'
FREEZE = ROOT / 'public-routing-freeze.json'
ENV = {**os.environ, 'PYTHONPATH': str(HARNESS / 'src'), 'OMP_NUM_THREADS': '1',
       'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def command(argv, timeout=15):
    process = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=True)
    return process.stdout


def snapshot():
    names = ['/etc/os-release', '/proc/version', '/proc/cpuinfo', '/proc/meminfo',
             '/sys/class/dmi/id/bios_vendor', '/sys/class/dmi/id/bios_version',
             '/sys/class/dmi/id/bios_date', '/sys/devices/system/cpu/smt/active',
             '/sys/devices/system/clocksource/clocksource0/current_clocksource']
    files = {name: Path(name).read_text() for name in names}
    for cpu in (96, 288):
        for name in ('topology/thread_siblings_list', 'cpufreq/scaling_governor',
                     'cpufreq/scaling_min_freq', 'cpufreq/scaling_max_freq'):
            path = Path(f'/sys/devices/system/cpu/cpu{cpu}') / name
            files[str(path)] = path.read_text() if path.exists() else 'not exposed'
    files['boost'] = Path('/sys/devices/system/cpu/cpufreq/boost').read_text()
    return {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'host': command(['hostname']),
            'files': files, 'packages': command(['dpkg-query', '-W']),
            'topology': command(['lscpu', '-e=CPU,CORE,SOCKET,NODE,ONLINE']),
            'processes': command(['ps', '-eo', 'pid,ppid,stat,pcpu,comm']),
            'loadavg': Path('/proc/loadavg').read_text(), 'stat': Path('/proc/stat').read_text(),
            'disk': command(['df', '-B1', str(ROOT)]), 'baseline_independent_attestation': False}


def verify_inputs(freeze):
    for section, base in (('input_sha256', ROOT), ('wheel_sha256', ROOT),
                          ('harness_python_sha256', HARNESS), ('bundle_sha256', HARNESS)):
        for relative, expected in freeze[section].items():
            assert digest(base / relative) == expected, (section, relative)
    assert digest(ROOT / 'installed-wheels/common/requirements.txt') == freeze['dependency_lock_sha256']


def workers():
    found = []
    for path in Path('/proc').glob('[0-9]*/comm'):
        try:
            if path.read_text().strip() == 'Runner.Worker':
                found.append(int(path.parent.name))
        except (FileNotFoundError, ProcessLookupError):
            continue  # Processes may exit while the snapshot is collected.
    return found


def phase(name, argv, budget):
    started = time.monotonic()
    with (ROOT / (name + '.log')).open('x') as log:
        process = subprocess.Popen(argv, cwd=HARNESS, env=ENV, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            while process.poll() is None:
                evidence = sorted(STUDY.glob('*/*/block-*/evidence.json')) if STUDY.exists() else []
                groups = []
                for group in PARENT.iterdir():
                    if group.is_dir():
                        groups.append({'name': group.name,
                                       'memory_bytes': int((group / 'memory.current').read_text()),
                                       'processes': (group / 'cgroup.procs').read_text().split(),
                                       'cpu_stat': (group / 'cpu.stat').read_text()})
                item = {'phase': name, 'elapsed_seconds': round(time.monotonic() - started, 1),
                        'completed_blocks': len(evidence), 'last_operation': str(evidence[-1]) if evidence else 'starting',
                        'memory_and_rank_activity': groups, 'loadavg': Path('/proc/loadavg').read_text().strip(),
                        'foreign_ci_workers': workers(), 'distribution_semantics': 'single_device_fast_path',
                        'collective_state': 'not applicable'}
                print(json.dumps(item), flush=True)
                with (ROOT / 'campaign-heartbeats.jsonl').open('a') as trace:
                    trace.write(json.dumps(item) + '\n')
                try:
                    process.wait(timeout=min(20, max(.01, budget - (time.monotonic() - started))))
                except subprocess.TimeoutExpired:
                    if time.monotonic() - started >= budget:
                        raise TimeoutError(name + ' exceeded explicit phase deadline')
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
                for group in PARENT.iterdir():
                    if group.is_dir() and (group / 'cgroup.procs').read_text().strip():
                        (group / 'cgroup.kill').write_text('1')
        result = {'phase': name, 'returncode': process.returncode,
                  'wall_seconds': time.monotonic() - started, 'log_sha256': digest(ROOT / (name + '.log'))}
        (ROOT / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)
        return result


assert not STUDY.exists(), 'Never overwrite a measured attempt'
assert not [p for p in PARENT.iterdir() if p.is_dir()], 'Existing study cgroups must finish before admission'
assert not workers(), 'Existing CI must finish naturally'
freeze = json.loads(FREEZE.read_text())
verify_inputs(freeze)
assert json.loads((ROOT / 'evaluator-controls.json').read_text())['returncode'] == 0
before = snapshot()
(ROOT / 'host-before.json').write_text(json.dumps(before, indent=2) + '\n')
assert before['host'].strip() == 'bm-srwl-sh-zone9-d-bw1100-144g-1-10'
assert before['files']['/sys/devices/system/cpu/cpu96/topology/thread_siblings_list'].strip() == '96,288'
os.sched_setaffinity(0, {96})
time.sleep(5)
assert not workers(), 'CI entered during admission'
# Preserve the raw idle interval so reviewers can inspect CPU 96 and sibling 288.
(ROOT / 'host-idle-interval.json').write_text(json.dumps({'seconds': 5, 'before': before['stat'],
    'after': Path('/proc/stat').read_text(), 'processes': command(['ps', '-eo', 'pid,ppid,stat,pcpu,comm'])}, indent=2) + '\n')
admission = {'scope': 'Operator-administered CPU routing controls; not release certification',
             'reservation_start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
             'duration_seconds': 86400, 'public_declaration_commit': '7c83c5f82480f49143190ed82f98c8fd757722ec',
             'public_declaration_pr': 1317, 'freeze_sha256': digest(FREEZE), 'host_before_sha256': digest(ROOT / 'host-before.json'),
             'baseline_independent_attestation': False, 'publication_eligible': False}
(ROOT / 'admission.json').write_text(json.dumps(admission, indent=2) + '\n')
argv = [str(PYTHON), '-m', 'sdkbench.candidates.cli', 'run', '--bundle', str(HARNESS / 'docs/implementation'),
        '--cpu', '96', '--cgroup-parent', str(PARENT), '--directory', str(STUDY)]
for stack in freeze['participants']:
    argv.extend(['--registration', str(ROOT / 'registrations' / (stack + '.json'))])
phase('routing-campaign-attempt-1', argv, 14500)
verify_inputs(freeze)
phase('routing-replay-attempt-1', [str(PYTHON), '-m', 'sdkbench.candidates.cli', 'replay',
      '--bundle', str(HARNESS / 'docs/implementation'), '--directory', str(STUDY)], 3600)
after = snapshot()
(ROOT / 'host-after.json').write_text(json.dumps(after, indent=2) + '\n')
assert before['packages'] == after['packages'], 'OS package baseline changed during attempt'
mutable = {'/proc/cpuinfo', '/proc/meminfo'}
assert {k: v for k, v in before['files'].items() if k not in mutable} == {k: v for k, v in after['files'].items() if k not in mutable}, 'Host stable baseline changed during attempt'
assert not workers(), 'Competing CI activity observed'
print(json.dumps({'phase': 'finished', 'study': str(STUDY), 'publication_eligible': False}), flush=True)
