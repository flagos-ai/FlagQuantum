import os,subprocess,json,hashlib
from pathlib import Path
root=Path('<redacted-path>
python='<redacted-path>
script=root/'artifacts/development/torch_training_cpu_20261103/reproduce.py'
paths={'before':Path('/tmp/fq936-training-before'),'after':root}
records=[]
for trial in range(3):
 phases=('before','after') if trial%2==0 else ('after','before')
 for phase in phases:
  output=Path(f'/tmp/fq936-unobserved-{phase}-{trial}')
  result=subprocess.run([python,str(script),'--output',str(output),'--without-callback','--only-default','--trials','1'],env={**os.environ,'FQ_TRAINING_SOURCE_ROOT':str(paths[phase])},timeout=600)
  print('phase',trial,phase,result.returncode,flush=True)
  data=json.loads((output/'campaign.json').read_text())
  for record in data['records']:
   record.update(paired_round=trial,phase=phase)
   records.append(record)
  Path('/tmp/fq936-unobserved-paired.json').write_text(json.dumps({'records':records,'phase_order':'before-after, after-before, before-after','native_extension_sha256':{key:hashlib.sha256((path/'flagquantum/simulation/native_cpu/_C.abi3.so').read_bytes()).hexdigest() for key,path in paths.items()}},indent=2)+'\n')
